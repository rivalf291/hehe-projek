<footer class="footer px-4">
        <div class="ms-auto"><a href="https://infonawala.id">Infonawala.id </a> &copy; 2025.</div>
        <!-- <div class="ms-auto">Powered by&nbsp;<a href="https://coreui.io/bootstrap/docs/">CoreUI UI Components</a></div> -->
      </footer>
    </div>
    <!-- CoreUI and necessary plugins-->
    <script src="vendors/@coreui/coreui/js/coreui.bundle.min.js"></script>
    <script src="vendors/simplebar/js/simplebar.min.js"></script>
    <script>
      const header = document.querySelector('header.header');
      
      document.addEventListener('scroll', () => {
        if (header) {
          header.classList.toggle('shadow-sm', document.documentElement.scrollTop > 0);
        }
      });
    </script>
    <!-- Plugins and scripts required by this view-->
    <!-- <script src="vendors/chart.js/dist/chart.umd.js"></script>
    <script src="vendors/@coreui/chartjs/dist/js/coreui-chartjs.js"></script> -->
    <script src="vendors/@coreui/utils/js/index.js"></script>
    <!-- <script src="js/main.js"></script> -->
    
    <!-- Bootstrap JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  </body>
</html>
